// class BodyApp
// driver/tester for class Body

import cs1.Keyboard;

public class BodyApp {

    public static void main( String [] args ) {

	Body boo = new Body();

	System.out.println("new body:");
	System.out.println(boo);
    
    }

}//end class BodyApp
