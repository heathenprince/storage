public class Body {

    // instance vars
    private String body;

    // default constructor
    public Body() {
	body = "   |   \n";
	body += "-------\n";
	body += "   |   \n";
	body += "  / \\  " + "\n";
	body += " /   \\ " + "\n";
    }

    public String toString() {
	return body;
    }

}

	
